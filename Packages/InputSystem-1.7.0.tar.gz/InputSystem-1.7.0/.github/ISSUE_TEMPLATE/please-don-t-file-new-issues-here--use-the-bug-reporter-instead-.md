---
name: PLEASE DON'T FILE NEW ISSUES HERE. Use the bug reporter instead.
about: Please use the bug reporter to file new issues
title: ''
labels: ''
assignees: ''

---

Hello,

If you have a bug to report, please file it as described here https://unity3d.com/unity/qa/bug-reporting
For general feedback and discussions you can go to https://forum.unity.com/forums/new-input-system.103/

Thank you!
