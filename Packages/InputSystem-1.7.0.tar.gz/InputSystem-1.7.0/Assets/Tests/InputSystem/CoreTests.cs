internal partial class CoreTests : CoreTestsFixture
{
}
